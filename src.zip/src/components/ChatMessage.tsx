import React from 'react';
import { useTheme } from '../contexts/ThemeContext';
import { formatTime } from '../utils/helpers';
import { ChatData } from '../types';
import { User, Bot } from 'lucide-react';

interface ChatMessageProps {
  message: ChatData;
}

const ChatMessage: React.FC<ChatMessageProps> = ({ message }) => {
  const { isDarkMode } = useTheme();
  const isUser = message.role === 'user';

  return (
    <div className={`flex ${isUser ? 'justify-end' : 'justify-start'} mb-4`}>
      <div className={`flex max-w-[80%] ${isUser ? 'flex-row-reverse' : 'flex-row'} items-start gap-2`}>
        {/* Avatar */}
        <div 
          className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
            isUser 
              ? 'bg-blue-100 text-blue-600'
              : 'bg-purple-100 text-purple-600'
          }`}
        >
          {isUser ? (
            <User size={16} />
          ) : (
            <Bot size={16} />
          )}
        </div>

        {/* Message Bubble */}
        <div 
          className={`
            p-3 rounded-lg shadow-sm
            ${isUser
              ? isDarkMode 
                ? 'bg-blue-600 text-white' 
                : 'bg-blue-500 text-white'
              : isDarkMode 
                ? 'bg-gray-800 text-white' 
                : 'bg-white text-gray-800'
            }
            animate-fadeIn
          `}
        >
          <div className="whitespace-pre-wrap">{message.content}</div>
          <div 
            className={`text-xs mt-1 text-right ${
              isUser 
                ? 'text-blue-200' 
                : isDarkMode ? 'text-gray-400' : 'text-gray-500'
            }`}
          >
            {formatTime(message.timestamp)}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChatMessage;
import React, { useRef, useEffect } from 'react';
import ChatMessage from './ChatMessage';
import ChatInput from './ChatInput';
import { Conversation } from '../types';
import { useTheme } from '../contexts/ThemeContext';

interface ChatWindowProps {
  conversation: Conversation;
  onSendMessage: (message: string) => void;
  isTyping?: boolean;
}

const ChatWindow: React.FC<ChatWindowProps> = ({ 
  conversation, 
  onSendMessage, 
  isTyping = false 
}) => {
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { isDarkMode } = useTheme();

  // Scroll to bottom when messages change or typing status changes
  useEffect(() => {
    scrollToBottom();
  }, [conversation?.messages, isTyping]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  // If conversation is undefined, show a loading state
  if (!conversation) {
    return (
      <div className={`flex flex-col h-full ${isDarkMode ? 'bg-gray-900' : 'bg-gray-50'}`}>
        <div className="flex-1 flex items-center justify-center">
          <div className={`text-center ${isDarkMode ? 'text-gray-300' : 'text-gray-600'}`}>
            <p className="text-lg">Loading conversation...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      {/* Chat Messages */}
      <div 
        className={`flex-1 overflow-y-auto p-4 ${
          isDarkMode ? 'bg-gray-900' : 'bg-gray-50'
        }`}
      >
        {(!conversation.messages || conversation.messages.length === 0) ? (
          <div className="h-full flex flex-col items-center justify-center">
            <div className={`max-w-md text-center ${isDarkMode ? 'text-gray-300' : 'text-gray-600'}`}>
              <h2 className="text-2xl font-bold mb-2">Welcome to IUB Chatbot</h2>
              <p className="mb-4">
                Start a conversation by typing a message below. Your chat history will be saved locally.
              </p>
              <p className="text-sm opacity-70">
                Try asking a question or share what's on your mind.
              </p>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            {conversation.messages.map((message) => (
              <ChatMessage key={message.id} message={message} />
            ))}
            {isTyping && (
              <div className="flex items-center">
                <div className={`p-4 rounded-lg max-w-[80%] ${
                  isDarkMode ? 'bg-gray-800' : 'bg-white'
                } shadow-sm`}>
                  <div className="flex space-x-2">
                    <div className={`w-2 h-2 rounded-full ${isDarkMode ? 'bg-gray-400' : 'bg-gray-500'} animate-bounce`} style={{ animationDelay: '0ms' }}></div>
                    <div className={`w-2 h-2 rounded-full ${isDarkMode ? 'bg-gray-400' : 'bg-gray-500'} animate-bounce`} style={{ animationDelay: '150ms' }}></div>
                    <div className={`w-2 h-2 rounded-full ${isDarkMode ? 'bg-gray-400' : 'bg-gray-500'} animate-bounce`} style={{ animationDelay: '300ms' }}></div>
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
        )}
      </div>

      {/* Input Area */}
      <div className={`border-t ${isDarkMode ? 'border-gray-700 bg-gray-800' : 'border-gray-200 bg-white'} p-4`}>
        <ChatInput onSendMessage={onSendMessage} disabled={isTyping} />
      </div>
    </div>
  );
};

export default ChatWindow;
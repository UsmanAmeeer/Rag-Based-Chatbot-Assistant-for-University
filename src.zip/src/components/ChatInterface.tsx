import React, { useState, useEffect } from 'react';
import ChatSidebar from './ChatSidebar';
import ChatWindow from './ChatWindow';
import { ChatData, Conversation } from '../types';
import { useTheme } from '../contexts/ThemeContext';
import { Menu, X } from 'lucide-react';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { generateUniqueId } from '../utils/helpers';

const ChatInterface: React.FC = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [conversations, setConversations] = useLocalStorage<Conversation[]>('chat-conversations', []);
  const [activeConversationId, setActiveConversationId] = useLocalStorage<string>('active-conversation-id', '');
  const [isLoading, setIsLoading] = useState(false);
  const { isDarkMode } = useTheme();

  useEffect(() => {
    if (conversations.length === 0) {
      const newConversation: Conversation = {
        id: generateUniqueId(),
        title: 'New Chat',
        messages: [],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        sessionId: generateUniqueId(), // Added sessionId
      };
      setConversations([newConversation]);
      setActiveConversationId(newConversation.id);
    } else if (!activeConversationId || !conversations.find(c => c.id === activeConversationId)) {
      setActiveConversationId(conversations[0].id);
    }
  }, [conversations, activeConversationId, setConversations, setActiveConversationId]);

  const activeConversation = conversations.find(c => c.id === activeConversationId) || conversations[0];

  const handleSendMessage = async (message: string) => {
    if (!message.trim()) return;

    const userMessage: ChatData = {
      id: generateUniqueId(),
      role: 'user',
      content: message,
      timestamp: new Date().toISOString(),
    };

    const updatedConversations = conversations.map(conv => {
      if (conv.id === activeConversationId) {
        const updatedTitle = conv.messages.length === 0 
          ? message.substring(0, 30) + (message.length > 30 ? '...' : '') 
          : conv.title;
        
        return {
          ...conv,
          title: updatedTitle,
          messages: [...conv.messages, userMessage],
          updatedAt: new Date().toISOString(),
        };
      }
      return conv;
    });
    
    setConversations(updatedConversations);
    setIsLoading(true);

    try {
      const response = await fetch('/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          question: message,
          session_id: activeConversation?.sessionId // Use conversation's sessionId
        }),
      });

      if (!response.ok) throw new Error('Failed to get response from server');
      const data = await response.json();

      const aiMessage: ChatData = {
        id: generateUniqueId(),
        role: 'assistant',
        content: data.answer || 'Sorry, I had trouble processing your request.',
        timestamp: new Date().toISOString(),
      };

      const finalConversations = conversations.map(conv => {
        if (conv.id === activeConversationId) {
          return {
            ...conv,
            messages: [...conv.messages, aiMessage],
            updatedAt: new Date().toISOString(),
          };
        }
        return conv;
      });
      
      setConversations(finalConversations);
    } catch (error) {
      console.error('Error fetching response:', error);
      
      const errorMessage: ChatData = {
        id: generateUniqueId(),
        role: 'assistant',
        content: 'Sorry, there was an error connecting to the server. Please try again later.',
        timestamp: new Date().toISOString(),
      };

      const errorConversations = conversations.map(conv => {
        if (conv.id === activeConversationId) {
          return {
            ...conv,
            messages: [...conv.messages, errorMessage],
            updatedAt: new Date().toISOString(),
          };
        }
        return conv;
      });
      
      setConversations(errorConversations);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCreateNewChat = () => {
    const newConversation: Conversation = {
      id: generateUniqueId(),
      title: 'New Chat',
      messages: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      sessionId: generateUniqueId(), // Generate new sessionId for each conversation
    };
    
    setConversations([newConversation, ...conversations]);
    setActiveConversationId(newConversation.id);
    setSidebarOpen(false);
  };

  const handleDeleteConversation = (id: string) => {
    const updatedConversations = conversations.filter(conv => conv.id !== id);
    
    if (updatedConversations.length === 0) {
      handleCreateNewChat();
    } else if (id === activeConversationId) {
      setActiveConversationId(updatedConversations[0].id);
    }
    
    setConversations(updatedConversations);
  };

  const handleSelectConversation = (id: string) => {
    setActiveConversationId(id);
    setSidebarOpen(false);
  };

  return (
    <div className={`h-screen flex flex-col md:flex-row overflow-hidden ${isDarkMode ? 'bg-gray-900 text-white' : 'bg-gray-50 text-gray-900'}`}>
      {/* Mobile Header */}
      <div className={`md:hidden flex items-center p-4 ${isDarkMode ? 'bg-gray-800' : 'bg-white'} border-b ${isDarkMode ? 'border-gray-700' : 'border-gray-200'}`}>
        <button 
          onClick={() => setSidebarOpen(true)} 
          className="p-2 rounded-md hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
          aria-label="Open sidebar"
        >
          <Menu size={24} className={isDarkMode ? 'text-gray-200' : 'text-gray-700'} />
        </button>
        <h1 className="ml-4 text-lg font-medium">
          {activeConversation?.title || 'Chat Interface'}
        </h1>
      </div>
      
      {/* Sidebar */}
      <div 
        className={`
          ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'} 
          md:translate-x-0
          fixed md:relative z-30 w-full md:w-80 h-full transition-transform duration-300 ease-in-out
          ${isDarkMode ? 'bg-gray-800' : 'bg-white'} 
          md:border-r ${isDarkMode ? 'border-gray-700' : 'border-gray-200'}
        `}
      >
        <div className="md:hidden absolute right-4 top-4">
          <button 
            onClick={() => setSidebarOpen(false)} 
            className="p-2 rounded-md hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
            aria-label="Close sidebar"
          >
            <X size={24} className={isDarkMode ? 'text-gray-200' : 'text-gray-700'} />
          </button>
        </div>
        
        <ChatSidebar 
          conversations={conversations}
          activeConversationId={activeConversationId}
          onSelectConversation={handleSelectConversation}
          onCreateNewChat={handleCreateNewChat}
          onDeleteConversation={handleDeleteConversation}
        />
      </div>
      
      {/* Overlay for mobile */}
      {sidebarOpen && (
        <div 
          className="md:hidden fixed inset-0 bg-black/50 z-20"
          onClick={() => setSidebarOpen(false)}
        />
      )}
      
      {/* Chat Window */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <ChatWindow 
          conversation={activeConversation}
          onSendMessage={handleSendMessage}
          isTyping={isLoading}
        />
      </div>
    </div>
  );
};

export default ChatInterface;
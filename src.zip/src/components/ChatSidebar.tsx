import React from 'react';
import { useTheme } from '../contexts/ThemeContext';
import { PlusCircle, Trash2, MessageSquare, Moon, Sun } from 'lucide-react';
import { Conversation } from '../types';
import { formatDate } from '../utils/helpers';

interface ChatSidebarProps {
  conversations: Conversation[];
  activeConversationId: string;
  onSelectConversation: (id: string) => void;
  onCreateNewChat: () => void;
  onDeleteConversation: (id: string) => void;
}

const ChatSidebar: React.FC<ChatSidebarProps> = ({
  conversations,
  activeConversationId,
  onSelectConversation,
  onCreateNewChat,
  onDeleteConversation,
}) => {
  const { isDarkMode, toggleTheme } = useTheme();

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className={`p-4 ${isDarkMode ? 'bg-gray-800' : 'bg-white'} border-b ${isDarkMode ? 'border-gray-700' : 'border-gray-200'}`}>
        <h1 className="text-lg font-semibold mb-2">IUB Chatbot</h1>
        <button
          onClick={onCreateNewChat}
          className="w-full flex items-center justify-center gap-2 py-2 px-4 rounded-md bg-blue-600 hover:bg-blue-700 text-white transition-colors"
        >
          <PlusCircle size={18} />
          <span>New Chat</span>
        </button>
      </div>

      {/* Conversation List */}
      <div className="flex-1 overflow-y-auto py-2">
        {conversations.length === 0 ? (
          <div className="text-center p-4 text-gray-500">No conversations yet</div>
        ) : (
          <ul>
            {conversations.map((conversation) => (
              <li key={conversation.id} className="px-2">
                <button
                  onClick={() => onSelectConversation(conversation.id)}
                  className={`w-full text-left p-3 rounded-md mb-1 flex justify-between items-start group transition-colors ${
                    conversation.id === activeConversationId
                      ? isDarkMode 
                        ? 'bg-gray-700 text-white' 
                        : 'bg-gray-200 text-gray-900'
                      : isDarkMode 
                        ? 'text-gray-300 hover:bg-gray-700' 
                        : 'text-gray-700 hover:bg-gray-100'
                  }`}
                >
                  <div className="flex items-start space-x-3 overflow-hidden">
                    <MessageSquare 
                      size={18} 
                      className={`mt-1 flex-shrink-0 ${
                        conversation.id === activeConversationId
                          ? 'text-blue-500'
                          : isDarkMode 
                            ? 'text-gray-400' 
                            : 'text-gray-500'
                      }`} 
                    />
                    <div className="overflow-hidden">
                      <p className="truncate font-medium">{conversation.title}</p>
                      <p className="text-xs text-gray-500 dark:text-gray-400">
                        {formatDate(conversation.updatedAt)}
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onDeleteConversation(conversation.id);
                    }}
                    className={`p-1 rounded-md opacity-0 group-hover:opacity-100 transition-opacity ${
                      isDarkMode ? 'hover:bg-gray-600' : 'hover:bg-gray-300'
                    }`}
                    aria-label="Delete conversation"
                  >
                    <Trash2 size={16} className="text-gray-500" />
                  </button>
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>

      {/* Footer */}
      <div className={`p-4 ${isDarkMode ? 'bg-gray-800' : 'bg-white'} border-t ${isDarkMode ? 'border-gray-700' : 'border-gray-200'}`}>
        <button
          onClick={toggleTheme}
          className={`w-full flex items-center justify-center gap-2 py-2 px-4 rounded-md ${
            isDarkMode 
              ? 'bg-gray-700 hover:bg-gray-600 text-white' 
              : 'bg-gray-200 hover:bg-gray-300 text-gray-800'
          } transition-colors`}
        >
          {isDarkMode ? (
            <>
              <Sun size={18} />
              <span>Light Mode</span>
            </>
          ) : (
            <>
              <Moon size={18} />
              <span>Dark Mode</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
};

export default ChatSidebar;
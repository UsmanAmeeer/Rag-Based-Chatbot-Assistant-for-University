import React, { useState, useRef, useEffect } from 'react';
import { useTheme } from '../contexts/ThemeContext';
import { Send } from 'lucide-react';

interface ChatInputProps {
  onSendMessage: (message: string) => void;
  disabled?: boolean;
}

const ChatInput: React.FC<ChatInputProps> = ({ onSendMessage, disabled = false }) => {
  const [message, setMessage] = useState('');
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const { isDarkMode } = useTheme();

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = '40px';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 120)}px`;
    }
  }, [message]);

  const handleSend = () => {
    if (message.trim() && !disabled) {
      onSendMessage(message);
      setMessage('');
      // Reset height
      if (textareaRef.current) {
        textareaRef.current.style.height = '40px';
      }
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className={`relative flex items-end rounded-md border ${
      isDarkMode 
        ? 'border-gray-700 bg-gray-700' 
        : 'border-gray-300 bg-gray-100'
    } ${disabled ? 'opacity-70' : ''}`}>
      <textarea
        ref={textareaRef}
        value={message}
        onChange={(e) => setMessage(e.target.value)}
        onKeyDown={handleKeyDown}
        placeholder="Type a message..."
        className={`w-full py-2 px-3 max-h-32 resize-none outline-none ${
          isDarkMode 
            ? 'bg-gray-700 text-white placeholder-gray-400' 
            : 'bg-gray-100 text-gray-900 placeholder-gray-500'
        } rounded-md`}
        rows={1}
        disabled={disabled}
      />
      <button
        onClick={handleSend}
        disabled={!message.trim() || disabled}
        className={`p-2 rounded-full mr-2 mb-2 ${
          message.trim() && !disabled
            ? 'bg-blue-600 hover:bg-blue-700 text-white'
            : isDarkMode 
              ? 'bg-gray-600 text-gray-400' 
              : 'bg-gray-300 text-gray-500'
        } transition-colors`}
        aria-label="Send message"
      >
        <Send size={18} />
      </button>
      <div className="absolute bottom-1 left-3 text-xs text-gray-500 dark:text-gray-400">
        Press Enter to send, Shift+Enter for new line
      </div>
    </div>
  );
};

export default ChatInput;